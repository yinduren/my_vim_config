namespace {
    extern int foo();
    extern int baz();
}

namespace {
    extern int foo();
}

namespace {
    extern int foo();
}
